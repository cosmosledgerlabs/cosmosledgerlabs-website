import { useEffect, useRef } from 'react'
import styles from './Hero.module.css'

export default function Hero() {
  const canvasRef = useRef(null)

  useEffect(() => {
    let renderer, animId, THREE

    async function init() {
      // 动态加载Three.js
      if (!window.THREE) {
        await new Promise((resolve) => {
          const s = document.createElement('script')
          s.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'
          s.onload = resolve
          document.head.appendChild(s)
        })
      }
      THREE = window.THREE
      const canvas = canvasRef.current
      if (!canvas) return

      renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true})
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
      renderer.setSize(canvas.offsetWidth, canvas.offsetHeight)

      const scene = new THREE.Scene()
      const camera = new THREE.OrthographicCamera(-1,1,1,-1,0,1)

      const fragShader = `
        uniform float u_time;
        uniform vec2 u_resolution;

        vec2 hash2(vec2 p){
          p = vec2(dot(p,vec2(127.1,311.7)), dot(p,vec2(269.5,183.3)));
          return -1.0 + 2.0*fract(sin(p)*43758.5453123);
        }
        float noise(vec2 p){
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f*f*(3.0-2.0*f);
          return mix(mix(dot(hash2(i+vec2(0,0)),f-vec2(0,0)),
                         dot(hash2(i+vec2(1,0)),f-vec2(1,0)),u.x),
                     mix(dot(hash2(i+vec2(0,1)),f-vec2(0,1)),
                         dot(hash2(i+vec2(1,1)),f-vec2(1,1)),u.x),u.y);
        }
        float fbm(vec2 p){
          float v = 0.0; float a = 0.5;
          vec2 shift = vec2(100.0);
          mat2 rot = mat2(cos(0.5),sin(0.5),-sin(0.5),cos(0.5));
          for(int i=0;i<5;i++){
            v += a*noise(p); p = rot*p*2.0+shift; a *= 0.5;
          }
          return v;
        }
        void main(){
          vec2 uv = gl_FragCoord.xy/u_resolution;
          vec2 st = uv - vec2(0.62,0.50);
          st.x *= u_resolution.x/u_resolution.y;
          float t = u_time*0.18;
          vec2 q = vec2(fbm(st+vec2(0.0,0.0)+t*0.3),fbm(st+vec2(5.2,1.3)+t*0.25));
          vec2 r = vec2(fbm(st+4.0*q+vec2(1.7,9.2)+t*0.2),fbm(st+4.0*q+vec2(8.3,2.8)+t*0.15));
          float f = fbm(st+4.0*r);
          float breath = 0.82+0.16*sin(u_time*2.856);
          float dist = length(st+0.5*q);
          float ring = smoothstep(0.45,0.30,dist)*smoothstep(0.08,0.20,dist);
          ring = pow(ring,0.8);
          float outerGlow = smoothstep(0.7,0.0,dist)*0.4;
          float intensity = (ring*(0.6+0.4*f)+outerGlow)*breath;
          vec3 col1 = vec3(0.0,0.35,1.0);
          vec3 col2 = vec3(0.0,0.65,1.0);
          vec3 col3 = vec3(0.05,0.85,1.0);
          vec3 col4 = vec3(0.4,0.95,1.0);
          vec3 color = mix(col1,col2,smoothstep(0.0,0.4,intensity));
          color = mix(color,col3,smoothstep(0.3,0.7,intensity));
          color = mix(color,col4,smoothstep(0.65,1.0,intensity));
          float center = smoothstep(0.12,0.0,dist);
          color *= (1.0-center*0.95);
          intensity *= (1.0-center*0.98);
          gl_FragColor = vec4(color*intensity, intensity*0.95);
        }
      `

      const mat = new THREE.ShaderMaterial({
        vertexShader: `void main(){gl_Position=vec4(position,1.0);}`,
        fragmentShader: fragShader,
        uniforms: {
          u_time: {value:0},
          u_resolution: {value: new THREE.Vector2(canvas.offsetWidth, canvas.offsetHeight)},
        },
        transparent: true,
        depthWrite: false,
      })

      scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2), mat))

      function resize() {
        const w = canvas.offsetWidth, h = canvas.offsetHeight
        renderer.setSize(w, h)
        mat.uniforms.u_resolution.value.set(w, h)
      }
      window.addEventListener('resize', resize)

      const clock = new THREE.Clock()
      function animate() {
        mat.uniforms.u_time.value = clock.getElapsedTime()
        renderer.render(scene, camera)
        animId = requestAnimationFrame(animate)
      }
      animate()
    }

    init()
    return () => {
      if (animId) cancelAnimationFrame(animId)
      if (renderer) renderer.dispose()
    }
  }, [])

  return (
    <section className={styles.hero} id="top">
      <canvas ref={canvasRef} className={styles.canvas} aria-hidden="true"/>
      <div className={styles.content}>
        <div className={styles.badge}>
          <span className={styles.badgeLight}/>
          <span className={styles.dot}/>
          // BUILT ON SOLANA
        </div>
        <h1 className={styles.title}>
          <span className={styles.tw}>Workflow Infrastructure for</span>
          <span className={styles.tw}><span className={styles.tc}>Digital Asset</span> Operations</span>
        </h1>
        <div className={styles.sub}>
          <div>
            <div className={styles.subLbl}>COMPANY</div>
            <div className={styles.subVal}>COSMOS LEDGER LABS</div>
          </div>
          <div className={styles.subDiv}/>
          <div>
            <div className={styles.subLbl}>INFRASTRUCTURE</div>
            <div className={`${styles.subVal} ${styles.dim}`}>WORKFLOW AUTOMATION</div>
          </div>
        </div>
        <div className={styles.glow}/>
        <p className={styles.body}>
          Secure workflow orchestration, approval coordination, transaction validation, monitoring, and recovery infrastructure for modern digital asset operations.
        </p>
        <div className={styles.btns}>
          <a href="#architecture" className={styles.btnP}>VIEW ARCHITECTURE</a>
          <a href="#contact" className={styles.btnS}>CONTACT US</a>
        </div>
      </div>
    </section>
  )
}
